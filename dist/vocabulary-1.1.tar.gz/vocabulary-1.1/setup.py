from setuptools import setup, find_packages

setup(name='vocabulary',
      version='1.1',
      description='vocabulary book server',
      author='Pham',
      license='MIT',
      packages=find_packages()
      )
